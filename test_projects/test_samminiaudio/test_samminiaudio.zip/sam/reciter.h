#ifndef RECITER_C
#define RECITER_C

//int TextToPhonemes(char *input, char *output);

int TextToPhonemes(char *input);

#endif
